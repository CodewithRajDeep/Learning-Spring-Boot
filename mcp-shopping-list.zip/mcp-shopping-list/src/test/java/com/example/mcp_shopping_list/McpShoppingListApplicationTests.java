package com.example.mcp_shopping_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McpShoppingListApplicationTests {

	@Test
	void contextLoads() {
	}

}
