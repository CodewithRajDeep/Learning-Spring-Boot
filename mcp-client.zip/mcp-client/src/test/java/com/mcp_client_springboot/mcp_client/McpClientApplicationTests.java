package com.mcp_client_springboot.mcp_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class McpClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
