package com.codeexample.learning.learningSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
